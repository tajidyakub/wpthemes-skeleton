<?php
/**
 * The template for displaying 404 error page
 * @link https://codex.wordpress.org/Template_Hierarchy
 */

get_header(); ?>


<?php
get_footer(); ?>