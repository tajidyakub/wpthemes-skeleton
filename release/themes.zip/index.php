<?php
/**
 * The main template file
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
*/
	get_header(); ?>



<?php
	get_footer(); ?>